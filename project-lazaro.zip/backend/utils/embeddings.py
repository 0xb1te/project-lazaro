from langchain_ollama import OllamaEmbeddings

def get_embeddings():
    return OllamaEmbeddings(model="hf.co/bartowski/DeepSeek-Coder-V2-Lite-Instruct-GGUF:Q8_0_L", base_url="http://localhost:11434")